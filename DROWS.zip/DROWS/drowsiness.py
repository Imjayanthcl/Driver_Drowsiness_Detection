import cv2
import numpy as np
import dlib
from scipy.spatial import distance
import time
import winsound  
def eye_aspect_ratio(eye):
    A = distance.euclidean(eye[1], eye[5])
    B = distance.euclidean(eye[2], eye[4])
    C = distance.euclidean(eye[0], eye[3])
    ear = (A + B) / (2.0 * C)
    return ear
def mouth_aspect_ratio(mouth):
    A = distance.euclidean(mouth[13], mouth[19])
    B = distance.euclidean(mouth[14], mouth[18])
    C = distance.euclidean(mouth[15], mouth[17])
    D = distance.euclidean(mouth[12], mouth[16])
    mar = (A + B + C) / (3.0 * D)
    return mar
predictor_path = "E:/drows/shape_predictor_68_face_landmarks.dat"
detector = dlib.get_frontal_face_detector()
predictor = dlib.shape_predictor(predictor_path)
cap = cv2.VideoCapture(0)
EAR_THRESHOLD = 0.25
CONSECUTIVE_FRAMES_THRESHOLD = 20
DELAY_THRESHOLD = 5
YAWN_THRESHOLD = 0.5
YAWN_DELAY_THRESHOLD = 3
frame_counter = 0
drowsy_alert_start_time = None
face_not_detected_start_time = None
yawning_start_time = None
while True:
    ret, frame = cap.read()
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = detector(gray)
    if not faces:
        if not face_not_detected_start_time:
            face_not_detected_start_time = time.time()
        elif time.time() - face_not_detected_start_time >= DELAY_THRESHOLD:
            print("Alert: Face not detected for 5 seconds!")
            winsound.PlaySound("E:/drows/facenotdetect.wav", winsound.SND_FILENAME)
    else:
        face_not_detected_start_time = None
    for face in faces:
        landmarks = predictor(gray, face)
        left_eye = np.array([(landmarks.part(n).x, landmarks.part(n).y) for n in range(36, 42)])
        right_eye = np.array([(landmarks.part(n).x, landmarks.part(n).y) for n in range(42, 48)])
        mouth = np.array([(landmarks.part(n).x, landmarks.part(n).y) for n in range(48, 68)])
        ear_left = eye_aspect_ratio(left_eye)
        ear_right = eye_aspect_ratio(right_eye)
        ear_avg = (ear_left + ear_right) / 2.0
        mar = mouth_aspect_ratio(mouth)
        cv2.polylines(frame, [left_eye], isClosed=True, color=(0, 255, 0), thickness=2)
        cv2.polylines(frame, [right_eye], isClosed=True, color=(0, 255, 0), thickness=2)
        if ear_avg < EAR_THRESHOLD:
            frame_counter += 1
            if frame_counter >= CONSECUTIVE_FRAMES_THRESHOLD:
                if not drowsy_alert_start_time:
                    drowsy_alert_start_time = time.time()
                    print("Drowsiness detected!")
                elif time.time() - drowsy_alert_start_time >= DELAY_THRESHOLD:
                    print("Alert: Driver is drowsy!")
                    winsound.PlaySound("E:/drows/alert.wav", winsound.SND_FILENAME)
        else:
            frame_counter = 0
            drowsy_alert_start_time = None
        if mar > YAWN_THRESHOLD:
            if not yawning_start_time:
                yawning_start_time = time.time()
                print("Yawning detected!")
        elif yawning_start_time and time.time() - yawning_start_time > YAWN_DELAY_THRESHOLD:
            print("Alert: Driver is yawning!")
            winsound.PlaySound("E:/drows/feelingtired.wav", winsound.SND_FILENAME)
            yawning_start_time = None
    cv2.imshow('Drowsiness Detection', frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
cap.release()
cv2.destroyAllWindows()